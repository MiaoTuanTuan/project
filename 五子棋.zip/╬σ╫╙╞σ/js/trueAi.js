
	function trueAi(c,d){
		var hei=0;
		var bei=0;
		var h=0;
		var b=0;
		var arr_hei=[];
		var arr_ber=[];
		for(var i=0;i<arr.length;i++){
			for(var k=0;k<arr[i].length;k++){
				if(arr[i][k]==0){
				     for(var a=0;a<4;a++){//判断右前方相同棋子数量
						 
						 if(arr[i][k+a]==1){
							 hei++;
						 }
						 if(arr[i][k+a]==2){
							 bei++;
						 }
					 }
				     if(hei==4){
				         h+=10000;		 
				     }else if(hei==3){
				     	 h+=1000;
				     }else if(hei==2){
				     	 h+=100;
				     }else if(hei==1){
				     	 h+=10;
				     }
				     if(bei==4){
				         b+=10000;		 
				     }else if(hei==3){
				     	 b+=1000;
				     }else if(hei==2){
				     	 b+=100;
				     }else if(hei==1){
				     	 b+=10;
				     }
					 //判断右后方
				     hei=0;
				     bei=0;
				     for(var a=0;a<4;a++){//判断右后方相同棋子数量
				     	if(arr[i][k-a]!=undefined&&arr[i][k-a]==1){
				  			 hei++;
				     	 }else if(arr[i][k-a]!=undefined&&arr[i][k-a]==2){
				     		 bei++;
				   		 }
				     }
				     //判断下方
				     hei=0;
				     bei=0;
				     for(var a=0;a<4;a++){//判断下方相同棋子数量
				     	 if(arr[(i+a)<arr.length?i+a:arr.length-1][k]==1){
				     		 hei++;
				         }else if(arr[(i+a)<arr.length?i+a:arr.length-1][k]==2){
				     		 bei++;
			    		 }
				     }
				    if(hei==4){
				        h+=10000;		 
				    }else if(hei==3){
				    	 h+=1000;
				    }else if(hei==2){
				    	 h+=100;
				    }else if(hei==1){
				    	 h+=10;
				    }
				    if(bei==4){
				        b+=10000;		 
				    }else if(hei==3){
				    	 b+=1000;
				    }else if(hei==2){
				    	 b+=100;
				    }else if(hei==1){
				    	 b+=10;
				    }				   
				    //判断上方
				    hei=0;
				    bei=0;
				    for(var a=0;a<4;a++){//判断上方相同棋子数量
				    	 if(arr[(i-a)>0?i-a:0][k]==1){
				    		 hei++;
				         }else if(arr[(i-a)>0?i-a:0][k]==2){
				    		 bei++;
				         }
				    }
				    if(hei==4){
				        h+=10000;		 
				    }else if(hei==3){
				    	 h+=1000;
				    }else if(hei==2){
				    	 h+=100;
				    }else if(hei==1){
				    	 h+=10;
				    }
				    if(bei==4){
				        b+=10000;		 
				    }else if(hei==3){
				    	 b+=1000;
				    }else if(hei==2){
				    	 b+=100;
				    }else if(hei==1){
				    	 b+=10;
				    }			
				    //判断左上角
				    hei=0;
				    bei=0;
				    for(var a=0;a<4;a++){//判断左上角相同棋子数量
				    	 if(arr[(i-a)>0?i-a:0][k-a]==1){
				    		 hei++;
				         }else if(arr[(i-a)>0?i-a:0][k-a]==2){
				    		 bei++;
				         }
				    }
				    if(hei==4){
				        h+=10000;		 
				    }else if(hei==3){
				    	 h+=1000;
				    }else if(hei==2){
				    	 h+=100;
				    }else if(hei==1){
				    	 h+=10;
				    }
				    if(bei==4){
				        b+=10000;		 
				    }else if(hei==3){
				    	 b+=1000;
				    }else if(hei==2){
				    	 b+=100;
				    }else if(hei==1){
				    	 b+=10;
				    }
					//判断右下角
					hei=0;
					bei=0;
					for(var a=0;a<4;a++){//判断左下角相同棋子数量
						 if(arr[(i+a)<arr.length?i+a:arr.length-1][k+a]==1){
							 hei++;
					     }else if(arr[(i+a)<arr.length?i+a:arr.length-1][k+a]==2){
							 bei++;
					     }
					}
					if(hei==4){
					    h+=10000;		 
					}else if(hei==3){
						 h+=1000;
					}else if(hei==2){
						 h+=100;
					}else if(hei==1){
						 h+=10;
					}
					if(bei==4){
					    b+=10000;		 
					}else if(hei==3){
						 b+=1000;
					}else if(hei==2){
						 b+=100;
					}else if(hei==1){
						 b+=10;
					}				
					//判断左下角
					hei=0;
					bei=0;
					for(var a=0;a<4;a++){//判断左下角相同棋子数量
						 if(arr[(i+a)<arr.length?i+a:arr.length-1][k-a]==1){
							 hei++;
					     }else if(arr[(i+a)<arr.length?i+a:arr.length-1][k-a]==2){
							 bei++;
					     }
					}
					if(hei==4){
					    h+=10000;		 
					}else if(hei==3){
						 h+=1000;
					}else if(hei==2){
						 h+=100;
					}else if(hei==1){
						 h+=10;
					}
					if(bei==4){
					    b+=10000;		 
					}else if(hei==3){
						 b+=1000;
					}else if(hei==2){
						 b+=100;
					}else if(hei==1){
						 b+=10;
					}				
					//判右上角
					hei=0;
					bei=0;
					for(var a=0;a<4;a++){//判断右上角相同棋子数量
						 if(arr[(i-a)>0?i-a:0][k+a]==1){
							 hei++;
					     }else if(arr[(i-a)>0?i-a:0][k+a]==2){
							 bei++;
					     }
					}
					if(hei==4){
					    h+=10000;		 
					}else if(hei==3){
						 h+=1000;
					}else if(hei==2){
						 h+=100;
					}else if(hei==1){
						 h+=10;
					}
					if(bei==4){
					    b+=10000;		 
					}else if(hei==3){
						 b+=1000;
					}else if(hei==2){
						 b+=100;
					}else if(hei==1){
						 b+=10;
					}									
     //                //判断棋子密集程度				
					//左右
					var front=(k-4)>0?k-4:0;
					var back=(k+4)<arr.length?k+4:arr.length-1;
					for(;front<back;front++){
						if(arr[i][front]==1){
							hei++;
						}
						if(arr[i][front]==2){
							bei++;
						}
					}			
					Ai();			
					//上下
					var front=(i-4)>0?i-4:0;
					var back=(i+4)<arr.length?i+4:arr.length-1;
					for(;front<back;front++){
						if(arr[front][k]==1){
							hei++;
						}
						if(arr[front][k]==2){
							bei++;
						}
					}			
					Ai();			
					//正斜
					var front=(i-4)>0?i-4:0;//以此处为中心点左右各延伸4，搜寻这条路径上相同的棋子
					var back=(k-4)>0?k-4:0;
					var front_z=(i+4)<arr.length?i+4:arr.length-1;
					var back_z=(k+4)<arr.length?k+4:arr.length-1;
					for(var i=0;front<front_z;front++,back++){
						if(arr[front][back]==1){
							hei++;
						}
						if(arr[front][back]==2){
							bei++;
						}
					}			
					Ai();
					反斜
					
					var front=(i+4)<arr.length?i+4:arr.length-1;//以此处为中心点左右各延伸4，搜寻这条路径上相同的棋子
					console.log(front);
					var back=(k-4)>0?k-4:0;
					var front_z=(i-4)<0?i-4:0;
					var back_z=(k+4)<arr.length?k+4:arr.length-1;
					for(var i=0;i<8;i++,front--,back++){
						if(arr[front][back]==1){
							hei++;
						}
						if(arr[front][back]==2){
							bei++;
						}
						
						
						
					}			
				    Ai();				
				    var obj_1={x:k,y:i,val:h};
					arr_hei.push(obj_1);
					var obj_1={x:k,y:i,val:b};
					arr_ber.push(obj_1);
					
					
					
				}	
			}
	
		}	
        function Ai(){
			if(hei==4){
			    h+=10000;		 
			}else if(hei==3){
				 h+=1000;
			}else if(hei==2){
				 h+=100;
			}else if(hei==1){
				 h+=10;
			}
			if(bei==4){
			    b+=10000;		 
			}else if(hei==3){
				 b+=1000;
			}else if(hei==2){
				 b+=100;
			}else if(hei==1){
				 b+=10;
			}
		}
        var  computr=0;//现在0表示黑棋，1表示白棋
        //要确定电脑现在是什么棋；一个参数是否先手，一个参数先手是生么棋
        if(c==0){//玩家先手了,电脑只有被动选择
        	if(d==0){//当前是黑棋
        		computr=1;
        	}else{//电脑就是白棋
        	    computr=0;	
        	}
        }else if(c==1){//电脑先手了
        	if(d==0){//电脑选了黑棋
        		computr=0;
        	}else{//玩家就是白棋
                computr=1;				
        	}
        }
        //1:数据采集完毕，找到最大的grade
        var t_hei=arr_hei[0];//0
        for(var i=0;i<arr_hei.length;i++){
        	if(i<arr_hei.length-1&&t_hei.val<arr_hei[i+1].val){
        		t_hei=arr_hei[i+1];
        	}
        }
        var t_ber=arr_ber[0];//1
        for(var i=0;i<arr_ber.length;i++){
        	if(i<arr_ber.length-1&&t_ber.val<arr_ber[i+1].val){
        		t_ber=arr_ber[i+1];
        	}
        }
        //2:将相同的最大值都提出来
        var temp_h=[];//0
        for(var i=0;i<arr_hei.length;i++){
        	if(t_hei.val==arr_hei[i].val){
        		temp_h.push(arr_hei[i]);
        	}
        	
        }
        var temp_b=[];//1
        for(var i=0;i<arr_ber.length;i++){
        	if(t_ber.val==arr_ber[i].val){
        		temp_b.push(arr_ber[i]);
        	}
        }
        if(computr==0){
			if(t_hei.val>t_ber.val){
				var sum=Math.floor(Math.random()*temp_h)
				x=temp_h[sum].x;
				y=temp_h[sum].y;
			}else{
				var sum=Math.floor(Math.random()*temp_b)
				x=temp_b[sum].x;
				y=temp_b[sum].y;
			}
				
		}else{
			if(t_hei.val>t_ber.val){
				var sum=Math.floor(Math.random()*temp_b)
				x=temp_b[sum].x;
				y=temp_b[sum].y;
			}else{
				var sum=Math.floor(Math.random()*temp_h)
				x=temp_h[sum].x;
				y=temp_h[sum].y;
			}
				
		}
        ctx.beginPath();//准备动作
		var  aa=0;
		for(var i=0;i<arr.length;i++){
			for(var j=0;j<arr[i].length;j++){
				if(arr[i][j]==0){
					aa++;
				}
			}
		}
		if(aa==(arr.length*arr.length)){//电脑走棋，第一次尽量定位在中间
		     var x_1=parseInt(arr.length/2);
			 var y_1=parseInt(arr.length/2);
			 ctx.arc(x_1*grid+grid/2,y_1*grid+grid/2,grid/2.5,0,Math.PI*2);//参数
		}else{
			 ctx.arc(x*grid+grid/2,y*grid+grid/2,grid/2.5,0,Math.PI*2);
		}
       
        if(bool==0){
        	ctx.fillStyle='black';
        	arr[y][x]=1;//黑子
        	bool=1;
        }else{
            ctx.fillStyle='white';	
        	arr[y][x]=2;//白子
        	bool=0;
        }
        //记录位置
        var temp=[y,x];
        arrRegret.push(temp);
        ctx.fill();
		//除了判断自己的权重，还要判断对手的权重，如果对手权重大于自己的权重，就去拦截对手
		
		
		
 
	}
	