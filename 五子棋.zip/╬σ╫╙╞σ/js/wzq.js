$(function(){
	var play=document.getElementById('play');
	var Mycan=document.getElementById('left').getElementsByTagName('canvas')[0];
	var ctx=Mycan.getContext('2d');
	var n=0;//棋盘大小初始变量
	var arrRegret=[];//记录每次下棋的位置，用于悔棋
	var arr=[];//棋盘数组
	var grid=0;//单个格子的大小；
	var pattern=0;//模式
	var sente=0;//是否先手
	var w_b=0;//黑白颜色
	var bool=0;
	var hui=0;//悔棋
	var r_hui=0;
	//模式选择
	$('#pattern li').on('click',function(){
		$('#pattern li').removeClass();
		$(this).addClass('one');
	});
	//是否先手，人机对战，才会生效
	$('#machine button').on('click',function(){
		$('#machine button').removeClass();
		$(this).addClass('one');
	})
	//先手棋子颜色
	$('#double button').on('click',function(){
		$('#double button').removeClass();
		$(this).addClass('one');
	})
	//启动函数
	play.onclick=function(){
	     $('#shade').hide();
	     $('#hint').hide();
		 var li_1=$('#pattern li');
		 var but_1=$('#machine button');
		 var but_2=$('#double button');
		 // 0 表示第一个选择，1表示第二个选择
		 //判断是是否含有选中类名
		    for(var i=0;i<li_1.length;i++){
			   if(li_1.eq(i).hasClass('one')){
				     pattern=i;
			    }
			    if(but_1.eq(i).hasClass('one')){
			         sente=i;
			    }
		        if(but_2.eq(i).hasClass('one')){
		             w_b=i;
		        }
		    }
			hui=pattern;
			r_hui=pattern;
			//渲染模式名
			var span=$('#right span');
			if(pattern==0){
				span.eq(0).text('双人模式');
			}else{
				span.eq(0).text('人机模式');
			}
			if(w_b==0){
				span.eq(3).text('黑棋');
			}else{
				span.eq(3).text('白棋');
			}
			var abc=w_b;
			//获取大小值
	 	    n=parseInt($('#qipan input').val());
		    span.eq(1).text(n);
			span.eq(2).text(n);
		    //判断先手颜色
			if(w_b==0){
				bool=true;
			}else{
				boo1=false;
			}
			//初始值
            arr=[];//棋盘数组
	        //全局变量
	        var width=$(Mycan).width();//画布是正方形获取一条边即可//元素宽带是写死的
            grid=width/n;//获取每个格子的大小；
	        canva(n);
		    //棋盘添加点击的函数/也需要传参数，这个参数是什么？
		    //切换模式 0表示双人，1表示人机
			$(Mycan).unbind('click');
		    switch(pattern){
			    case 0:
                    shuangRen();
			        break;
			    case 1:
				    switch(sente){
						case 0:  //如果玩家先走
						    shuangRen_2()
						     break;
							
                        case 1:  //如果电脑先走
						    ai(sente,w_b);
						    shuangRen_3();
							break;
					}
				   break;
			}
			$('#right ul li:nth-child(2)').off('click').on('click',function(){
               
				if(pattern==0){
				    regret();
					bool!=bool;
				}
				if(pattern==1){
					regret();
					bool!=bool;
					regret();
					bool!=bool;
				}
				
			});
			return;
			function shuangRen_3(){
				$(Mycan).on('click',function(ev){
				  	ev=ev||event;
				  	var x=ev.pageX-$(this).offset().left;
				  	var y=ev.pageY-$(this).offset().top;
				  	//锁定位置
				  	var row,col;
				  	row=parseInt(y/grid);
				  	col=parseInt(x/grid);
				  	var x_1 =grid/2+col*grid;
				  	var y_1 =grid/2+row*grid;
				  	//我的起始坐标是根据传入的参数由画布的大小决定，每次参数变化，位置不同；
				  	//x值与y值是鼠标相对于文档边缘的值减去画布到文档的距离
				  	//也就是说x值y值就是鼠标点击位置到画布边缘的值；
				  	//棋盘起始位置，是单个格子宽度的一半，相对于画布左上角；
				  	//转换为二维数组下标；y轴相当于二位数组的一维下标，x轴相当于二维数组的二维下标；
				  	if(arr[row][col]!=0){
				  		return;
				  	} 
				     var abc=bool;
					 if(bool){
					 	$('#sspan').text('黑子');
					 }else{
					     ctx.fillStyle='white';	
                         $('#sspan').text('白子');
					 }
				  	ctx.beginPath();//准备动作
				  	ctx.arc(x_1,y_1,grid/2.5,0,Math.PI*2);//参数
				  	if(bool){
				  		ctx.fillStyle='black';
				  		arr[row][col]=1;//黑子
				  		bool=false;
				  	}else{
				  	    ctx.fillStyle='white';	
				  		arr[row][col]=2;//白子
				  		bool=true;
				  	}
				  	//记录位置
				  	var temp=[row,col];
				  	arrRegret.push(temp);
				  	ctx.fill();
				    ai(sente,w_b);
				 	judeg();
					hui=0;
				  });		
			}
			function shuangRen_2(){
				$(Mycan).on('click',function(ev){
				  	ev=ev||event;
				  	var x=ev.pageX-$(this).offset().left;
				  	var y=ev.pageY-$(this).offset().top;
				  	//锁定位置
				  	var row,col;
				  	row=parseInt(y/grid);
				  	col=parseInt(x/grid);
				  	var x_1 =grid/2+col*grid;
				  	var y_1 =grid/2+row*grid;
				  	//我的起始坐标是根据传入的参数由画布的大小决定，每次参数变化，位置不同；
				  	//x值与y值是鼠标相对于文档边缘的值减去画布到文档的距离
				  	//也就是说x值y值就是鼠标点击位置到画布边缘的值；
				  	//棋盘起始位置，是单个格子宽度的一半，相对于画布左上角；
				  	//转换为二维数组下标；y轴相当于二位数组的一维下标，x轴相当于二维数组的二维下标；
				  	if(arr[row][col]!=0){
				  		return;
				  	} 
				     var abc=bool;
				     if(abc){
				     	$('#sspan').text('黑子')
				     }else{
				         ctx.fillStyle='white';	
				         $('#sspan').text('白子')
				     }
				  	ctx.beginPath();//准备动作
				  	ctx.arc(x_1,y_1,grid/2.5,0,Math.PI*2);//参数
				  	if(bool){
				  		ctx.fillStyle='black';
				  		arr[row][col]=1;//黑子
				  		bool=false;
				  	}else{
				  	    ctx.fillStyle='white';	
				  		arr[row][col]=2;//白子
				  		bool=true;
				  	}
				  	//记录位置
				  	var temp=[row,col];
				  	arrRegret.push(temp);
				  	ctx.fill();
				 	ai(sente,w_b);
				 	judeg();
					hui=0;
				  });		
			}
	        function shuangRen(){
		        $(Mycan).on('click',function(ev){
		        	ev=ev||event;
		        	var x=ev.pageX-$(this).offset().left;
		        	var y=ev.pageY-$(this).offset().top;
		        	//锁定位置
		        	var row,col;
		        	row=parseInt(y/grid);
		        	col=parseInt(x/grid);
		        	var x_1 =grid/2+col*grid;
		        	var y_1 =grid/2+row*grid;
		        	//我的起始坐标是根据传入的参数由画布的大小决定，每次参数变化，位置不同；
		        	//x值与y值是鼠标相对于文档边缘的值减去画布到文档的距离
		        	//也就是说x值y值就是鼠标点击位置到画布边缘的值；
		        	//棋盘起始位置，是单个格子宽度的一半，相对于画布左上角；
		        	//转换为二维数组下标；y轴相当于二位数组的一维下标，x轴相当于二维数组的二维下标；
		        	if(arr[row][col]!=0){
		        		return;
		        	} 
				   var abc=bool;
				   if(abc){
				   	    $('#sspan').text('请白子')
				   	    abc=false;
				   }else{
				       ctx.fillStyle='white';	
				       $('#sspan').text('请黑子')
				   	   abc=true;
				   }
		        	ctx.beginPath();//准备动作
		        	ctx.arc(x_1,y_1,grid/2.5,0,Math.PI*2);//参数
		        	if(bool){
		        		ctx.fillStyle='black';
		        		arr[row][col]=1;//黑子
		        		bool=false;
		        	}else{
		        	    ctx.fillStyle='white';	
		        		arr[row][col]=2;//白子
		        		bool=true;
		        	}
					//记录位置
					var temp=[row,col];
					arrRegret.push(temp);
		        	ctx.fill();
		        	judeg();
					hui=0;
		        });		
			}
		
	//1：生成函数
	function canva(n){
		//绘制棋盘 生成数组
		//先画出来，再做处理
	    //不把起点位置写死，根据输入的值来判断,
	    for (var i = 0; i <n; i++) {
			//横线
	        ctx.moveTo(grid/2,grid/2+i*grid);
	        ctx.lineTo(width-grid/2,grid/2+grid*i);
	        //竖线
			ctx.moveTo(grid/2+i*grid,grid/2);
	        ctx.lineTo(grid/2+i*grid,width-grid/2);   
	    }
	    ctx.stroke();
		//new一个长度为n的数组，每一个值为零，赋值给棋盘数组
		// 0表示空  1，表示黑棋  2表示白棋
        for(var i=0;i<n;i++){
			var temp=[];
				for(var k=0;k<n;k++){
					temp[k]=0;
				}
			arr.push(temp);
			
		}
	}
	//3：判断函数，判断输赢
	function judeg(){
		//顺序判断
		var t=0;
		for(var i=0;i<arr.length;i++){
			for(var k=0;k<arr[i].length;k++){
			    if(arr[i][k]==1){//判断一行相邻五个数是否相等
					if(arr[i][k]==arr[i][k+1]&&arr[i][k]==arr[i][k+2]&&arr[i][k]==arr[i][k+3]&&arr[i][k]==arr[i][k+4]){
		                 $('.show_2 h1').text('黑方胜');
						   $('.show_2 p').text('可开始新游戏');
						 ctx.moveTo(grid/2+k*grid,grid/2+i*grid);
						 ctx.lineTo(grid/2+(k+4)*grid,grid/2+i*grid);
						 ctx.strokeStyle ='darkorange';
						 ctx.lineWidth='5';
						 ctx.stroke();
						 $(Mycan).unbind('click');
		                 break;
					}
				} 
				if(arr[i][k]==2){//判断一行相邻五个数是否相等
					if(arr[i][k]==arr[i][k+1]&&arr[i][k]==arr[i][k+2]&&arr[i][k]==arr[i][k+3]&&arr[i][k]==arr[i][k+4]){
				         ctx.moveTo(grid/2+k*grid,grid/2+i*grid);
				         ctx.lineTo(grid/2+(k+4)*grid,grid/2+i*grid);
				         ctx.strokeStyle ='darkorange';
						 ctx.lineWidth='5';
				         ctx.stroke();
						 $(Mycan).unbind('click');
						 $('.show_2 h1').text('白方胜');
					     $('.show_2 p').text('可开始新游戏');
						 break;
					}
				} 	//判断一列相邻五个数是否相等
		        if(arr[k][i]==1){
					if(arr[k+4]!=undefined&&arr[k][i]==arr[k+1][i]&&arr[k][i]==arr[k+2][i]&&arr[k][i]==arr[k+3][i]&&arr[k][i]==arr[k+4][i]){
						ctx.moveTo(grid/2+i*grid,grid/2+k*grid);
						ctx.lineTo(grid/2+i*grid,grid/2+(k+4)*grid);
						ctx.strokeStyle ='darkorange';
						ctx.lineWidth='5';
						ctx.stroke();
						$(Mycan).unbind('click');
						$('.show_2 p').text('可开始新游戏');
						$('.show_2 h1').text('黑方胜');
						break;
					}
				}
		        if(arr[k][i]==2){
		        	if(arr[k+4]!=undefined&&arr[k][i]==arr[k+1][i]&&arr[k][i]==arr[k+2][i]&&arr[k][i]==arr[k+3][i]&&arr[k][i]==arr[k+4][i]){
		        		ctx.moveTo(grid/2+i*grid,grid/2+k*grid);
		        		ctx.lineTo(grid/2+i*grid,grid/2+(k+4)*grid);
		        		ctx.strokeStyle ='darkorange';
						ctx.lineWidth='5';
		        		ctx.stroke();
						$(Mycan).unbind('click');
						$('.show_2 h1').text('白方胜');
						$('.show_2 p').text('可开始新游戏');
		        		break;
		        	}
		        }
		        //判断正对角
		        if(arr[i][k]==1&k<arr.length-4&&i<arr.length-4){
		        	if(arr[i][k]==arr[i+1][k+1]&&arr[i][k]==arr[i+2][k+2]&&arr[i][k]==arr[i+3][k+3]&&arr[i][k]==arr[i+4][k+4]){
		        		ctx.moveTo(grid/2+k*grid,grid/2+i*grid);
		        		ctx.lineTo(grid/2+(k+4)*grid,grid/2+(i+4)*grid);
		        		ctx.strokeStyle ='darkorange';
						ctx.lineWidth='5';
		        		ctx.stroke();
						$(Mycan).unbind('click');
					    $('.show_2 h1').text('黑方胜');
						$('.show_2 p').text('可开始新游戏');
		        		break;
		        	}
		        }
		        if(arr[i][k]==2&k<arr.length-4&&i<arr.length-4){
		        	if(arr[i][k]==arr[i+1][k+1]&&arr[i][k]==arr[i+2][k+2]&&arr[i][k]==arr[i+3][k+3]&&arr[i][k]==arr[i+4][k+4]){
		        		ctx.moveTo(grid/2+k*grid,grid/2+i*grid);
						ctx.lineTo(grid/2+(k+4)*grid,grid/2+(i+4)*grid);
		        		ctx.strokeStyle ='darkorange';
		        		ctx.lineWidth='5';
		        		ctx.stroke();
						$(Mycan).unbind('click');
						$('.show_2 h1').text('白方胜');
						$('.show_2 p').text('可开始新游戏');
		        		break;
		        	}
		        }
		        //判断反对角
		        if(arr[i][k]==1&&k>4&&i<arr.length-4){
		        	if(arr[i][k]==arr[i+1][k-1]&&arr[i][k]==arr[i+2][k-2]&&arr[i][k]==arr[i+3][k-3]&&arr[i][k]==arr[i+4][k-4]){
		        		ctx.moveTo(grid/2+k*grid,grid/2+i*grid);
		        		ctx.lineTo(grid/2+(k-4)*grid,grid/2+(i+4)*grid);
		        		ctx.strokeStyle ='darkorange';
		        		ctx.lineWidth='5';
		        		ctx.stroke();
		        		$(Mycan).unbind('click');
		        		$('.show_2 h1').text('黑方胜');
						$('.show_2 p').text('可开始新游戏');
		        		break;
		        	}
		        }
		        if(arr[i][k]==2&&k>4&&i<arr.length-4){
		        	if(arr[i][k]==arr[i+1][k-1]&&arr[i][k]==arr[i+2][k-2]&&arr[i][k]==arr[i+3][k-3]&&arr[i][k]==arr[i+4][k-4]){
		        		ctx.moveTo(grid/2+k*grid,grid/2+i*grid);
		        		ctx.lineTo(grid/2+(k-4)*grid,grid/2+(i+4)*grid);
		        		ctx.strokeStyle ='darkorange';
		        		ctx.lineWidth='5';
		        		ctx.stroke();
						$(Mycan).unbind('click');
						$('.show_2 h1').text('白方胜');
		        		$('.show_2 p').text('可开始新游戏');
						break;
		        	}
		        }
			    
				if(arr[i][k]==0){
					t++;
				}
			}
		}
        if(t==0){
			$(Mycan).unbind('click');
			 $('.show_2 h1').text('平局');
		}
        
	}
	
	//思路，现在需要一个主函数，当打开之后里面的函数才会生效；	
	}
	
	//启动新游戏
	$('#right ul li').eq(0).on('click',function(){
		    $('#shade').show();
			$('#hint').show();
			Mycan.height=Mycan.height;
			arrRegret=[];
			$('.show_2 p').text('');
			$('.show_2 h1').text('');
			$('#sspan').text('');
	});
	//电脑下棋//假设1是电脑2 是玩家，计算黑棋与白棋的权重
	function ai(c,d){
		var temp=[];//每一个点都进行记录,电脑
		var rival=[];//玩家
		var three_1=0;
		var three_2=0;
		var two_1=[];//等于2的时候
		var two_2=[];
	    var three_1=[];//等于3的时候
		var three_2=[];
		var four_1=[];//等于4的时候表示黑棋
		var four_2=[];
		//遍历数组每一个值为零的点，八个方向搜索，可能会出现的某种情况		
				for(var i=0;i<arr.length;i++){
					for(var k=0;k<arr[i].length;k++){
						if(arr[i][k]==0){
							//左右判断
							var obj={
								grade:0,
								y:i,
								x:k
							};
							var obj_1={
								grade:0,
								y:i,
								x:k
							};
							var t=0;//电脑
							var t_1=0;//玩家
							var m=0;
							var m_1=0;
							//1表示黑棋  2表示白棋
							//保存坐标,最优值 4个为10000，三个为1000，两个为100，一个为10，零个为0
							for(var a=(k-4>0?k-4:0);a<k;a++){
								if(arr[i][a]==1){
									t++;
								}else if(arr[i][a]==0){
									t+=0;
								}
								else{
									t-=1;
								}
								if(arr[i][a]==2){
									t_1++;
								}else if(arr[i][a]==0){
									t+=0;
								}
								else{
									t_1-=1;
								}
							}
							//电脑
							detection();
							//向右判断
							t=0;
							t_1=0;
							for(var a=(k+4<arr.length?k+4:arr.length-1);a>k;a--){
								if(arr[i][a]==1){
									t++;
								}else if(arr[i][a]==0){
									t+=0;
								}
								else{
									t-=1;
								}
								if(arr[i][a]==2){
									t_1++;
								}else if(arr[i][a]==0){
									t+=0;
								}
								else{
									t_1-=1;
								}
							}
							//电脑
							detection();
							//上判断
							t=0;
							t_1=0;
							for(var a=(i-4>=0?i-4:0) ;a<i;a++){
								if(arr[a][k]==1){
									t++;
								} else if(arr[a][k]==0){
									t+=0;
								}
								else{
									t-=1;
								}
								if(arr[a][k]==2){
									t++;
								}else if(arr[a][k]==0){
									t+=0;
								}
								else{
									t_1-=1;
								}
								
							}
							//电脑
							 detection();
							//下判断
							t=0;
							t_1=0;
							for(var a=(i+4<arr.length?i+4:arr.length-1);a>i;a--){
								if(arr[a][k]==1){
									t++;
								}else if(arr[a][k]==0){
									t+=0;
								}
								else{
									t-=1;
								}
								if(arr[a][k]==2){
									t_1++;
								}else if(arr[a][k]==0){
									t+=0;
								}
								else{
									t_1-=1;
								}
							}
							//电脑
							 detection();
							//左上
							t=0;
							t_1=0;
							for(var a=(i-4>=0?i-4:0),b=(k-4>=0?k-4:0);a<i;a++,b++){
							    if(arr[a][b]==1){
							    	t++;
							    }else if(arr[a][b]==0){
							    	t+=0;
							    }
							    else{
							    	t-=1;
							    }
							    if(arr[a][b]==2){
							    	t++;
							    }else if(arr[a][b]==0){
							    	t+=0;
							    }
							    else{
							    	t_1-=1;
							    }
							}
							detection();
							//右下
							t=0;
							t_1=0;
							for(var a=(i+4<arr.length?i+4:arr.length-1),b=(k+4<arr.length?k+4:arr.length-1);a>i;a--,b--){
								if(arr[a][b]==1){
									t++;
								}else if(arr[a][b]==0){
									t+=0;
								}
								else{
									t-=1;
								}
								if(arr[a][b]==2){
									t++;
								}else if(arr[a][b]==0){
									t+=0;
								}
								else{
									t_1-=1;
								}
							}
							detection();
							//右上
							t=0;
							t_1=0;
							for(var a=(i-4>=0?i-4:0),b=(k+4<arr.length?k+4:arr.length-1);a<i;a++,b--){
								if(arr[a][b]==1){
									t++;
								}else if(arr[a][b]==0){
									t+=0;
								}
								else{
									t-=1;
								}
								if(arr[a][b]==2){
									t++;
								}else if(arr[a][b]==0){
									t+=0;
								}
								else{
									t_1-=1;
								}
							}
							detection();
							//右下
							t=0;t_1=0;
							for(var a=(i+4<arr.length?i+4:arr.length-1),b=(k-4>=0?k-4:0);a>i;a--,b++){
								if(arr[a][b]==1){
									t++;
								}else if(arr[a][b]==0){
									t+=0;
								}
								else{
									t-=1;
								}
								if(arr[a][b]==2){
									t_1++;
								}else if(arr[a][b]==0){
									t+=0;
								}
								else{
									t_1-=1;
								}
							}
							detection();
							//判断棋子密集程度
												//左右
							    t=0;t_1=0;
								var front=(k-4)>0?k-4:0;
								var back=(k+4)<arr.length?k+4:arr.length-1;
								for(;front<back;front++){
									if(arr[i][front]==1){
									    t++;
									}
									if(arr[i][front]==2){
									    t_1++;
									}
								}			
								detection();			
								//上下
								t=0;t_1=0;                                                                                     
								var front=(i-4)>0?i-4:0;
								var back=(i+4)<arr.length?i+4:arr.length-1;
								for(;front<back;front++){
								    if(arr[front][k]==1){
										t++;
									}
									if(arr[front][k]==2){
										t_1++;
									}
								}
							
								detection();
                                //正斜
								t=0;t_1=0;
								var hx=k-4<0?0:k-4;
								var sy=i-4<0?0:i-4;
								var hx_1=k+4>arr.length?arr.length-1:k+4;
								var sy_1=i+4>arr.length?arr.length-1:i+4;
								for(;sy<sy_1;sy++,hx++){
										if(arr[sy][hx]==1){
											t++;
											if(t>4){
												t=4;
											}
											
										}
										if(arr[sy][hx]==2){
											
											t_1++;
											if(t_1>4){
												t=4;
											}
										}
									
								}
								detection();
								//反斜
								t=0;t_1=0;
								var hx=k-4<0?0:k-4;
								var sy=i-4<0?0:i-4;
								var hx_1=k+4>arr.length?arr.length-1:k+4;
								var sy_1=i+4>arr.length?arr.length-1:i+4;
								for(;sy<sy_1;sy++,hx_1--){
										if(arr[sy][hx_1]==1){
											t++;
										}
										if(arr[sy][hx]==2){
											t_1++;
										}
								}
								detection();
								//9内格采集
								t=0;t_1=0; 
								var hx=k-1<0?0:k-1;
								var sy=i-1<0?0:i-1;
								var hx_1=k+1>arr.length?arr.length-1:k+1;
								var sy_1=i+1>arr.length?arr.length-1:i+1;
								for(;sy<sy_1;sy++){
									for(;hx<hx_1;hx++){
										if(arr[sy][hx]==1){
											t++;
											if(t>4){
												t=4;
											}
											
										}
										if(arr[sy][hx]==2){
											
											t_1++;
											if(t_1>4){
												t=4;
											}
										}
									}
								}
								detection();
								//25内格采集
								t=0;t_1=0; 
								var hx=k-2<0?0:k-2;
								var sy=i-2<0?0:i-2;
								var hx_1=k+2>arr.length?arr.length-1:k+2;
								var sy_1=i+2>arr.length?arr.length-1:i+2;
								for(;sy<sy_1;sy++){
									for(;hx<hx_1;hx++){
										if(arr[sy][hx]==1){
											t++;
											if(t>4){
												t=4;
											}
											
										}
										if(arr[sy][hx]==2){
											
											t_1++;
											if(t_1>4){
												t=4;
											}
			                            }		
									}
									
								}
								detection();
								
				    	    obj={
								y:i,
								x:k,
								grade:m
							}
				            temp.push(obj);
							obj_1={
								y:i,
						    	x:k,
						    	grade:m_1
							}
							 rival.push(obj_1);
					    }
					}//循环
					
				}//循环
		function detection(){
			if(t==4){
				m+=10000;
				var obj_3={x:k,y:i}
				four_1.push(obj_3);
			}
			if(t==3){
				m+=1000;
				var obj_3={x:k,y:i}
				three_1.push(obj_3);
			}
			if(t==2){
				m+=100;
			    var obj_3={x:k,y:i}
				two_1.push(obj_3);
			}
			if(t==1){
				m+=10;
			}
			if(t_1==4){
				m_1+=10000;
				var obj_3={x:k,y:i}
				four_2.push(obj_3);
			}
			if(t_1==3){
				m_1+=1000;
				var obj_3={x:k,y:i}
				three_2.push(obj_3);
			}
			if(t_1==2){
				m_1+=100;
				var obj_4={x:k,y:i}
				two_2.push(obj_4);
				
			}
			if(t_1==1){
				m_1+=10;
   			}
		}
		var  computr=0;//现在0表示黑棋，1表示白棋
		//要确定电脑现在是什么棋；一个参数是否先手，一个参数先手是生么棋
		if(c==0){//玩家先手了,电脑只有被动选择
			if(d==0){//当前是黑棋
				computr=1;
			}else{//电脑就是白棋
			    computr=0;	
			}
		}else if(c==1){//电脑先手了
			if(d==0){//电脑选了黑棋
				computr=0;
			}else{//玩家就是白棋
                computr=1;				
			}
		}
        //1:数据采集完毕，找到最大的grade
		var temporary=temp[0];//0
        for(var i=0;i<temp.length;i++){
			if(i<temp.length-1&&temporary.grade<temp[i+1].grade){
				temporary=temp[i+1];
			}
	    }
		var temporary_1=rival[0];//1
		for(var i=0;i<rival.length;i++){
			if(i<rival.length-1&&temporary_1.grade<rival[i+1].grade){
				temporary_1=rival[i+1];
			}
		}
		
		//2:将相同的最大值都提出来
		var temp_2=[];//0
		for(var i=0;i<temp.length;i++){
			if(temporary.grade==temp[i].grade){
				temp_2.push(temp[i]);
			}
			
		}
		var temp_3=[];//1
		for(var i=0;i<rival.length;i++){
			if(temporary_1.grade==rival[i].grade){
				temp_3.push(rival[i]);
			}
			
		}
		var x,y,sum;
		if(computr=0){//表示电脑现在是黑棋
			    var sum_1=Math.floor(Math.random()*temp_2.length);
			    var sum_2=Math.floor(Math.random()*temp_3.length);
			    if(temp_2[sum_1].grade>temp_3[sum_2].grade){
			    	x=temp_2[sum_1].x ;
			    	y=temp_2[sum_1].y ;	
			    }
			    else{
			    	x=temp_3[sum_2].x ;
			    	y=temp_3[sum_2].y ;	
			    }
			// }
		}else{//表示电脑现在是白棋
				var sum_1=Math.floor(Math.random()*temp_2.length);
				var sum_2=Math.floor(Math.random()*temp_3.length);
				if(temp_3[sum_2].grade>temp_2[sum_1].grade){
					x=temp_3[sum_2].x ;
					y=temp_3[sum_2].y ;	
				}
				else{
					x=temp_2[sum_1].x ;
					y=temp_2[sum_1].y ;	
				}
			}	
		// }
        ctx.beginPath();//准备动作
        ctx.arc(x*grid+grid/2,y*grid+grid/2,grid/2.5,0,Math.PI*2);
        if(bool){
        	ctx.fillStyle='black';
        	arr[y][x]=1;//黑子
        	bool=false;
        }else{
            ctx.fillStyle='white';	
        	arr[y][x]=2;//白子
        	bool=true;
        }
        //记录位置
        var temp=[y,x];
        arrRegret.push(temp);
        ctx.fill();
		//除了判断自己的权重，还要判断对手的权重，如果对手权重大于自己的权重，就去拦截对手
		
		
	}//函数
	//悔棋 传入参数，记录每次下棋的位置，二维数组里相应位置的数重新赋值为零，清掉棋盘上相应位置的棋子；
 
	function regret(){
		if(arrRegret.length==0){
			return;
		}
			var temp=arrRegret.pop()
			arr[temp[0]][temp[1]]=0;
			Mycan.height=Mycan.height;
			//重绘棋盘
			var width=$(Mycan).width();
			var grid=width/arr.length;
			for (var i = 0; i <n; i++) {
				//横线
			    ctx.moveTo(grid/2,grid/2+i*grid);
			    ctx.lineTo(width-grid/2,grid/2+grid*i);
			    //竖线
				ctx.moveTo(grid/2+i*grid,grid/2);
			    ctx.lineTo(grid/2+i*grid,width-grid/2);   
			}
			ctx.stroke();
			for(var i=0;i<arr.length;i++){
				for(var k=0;k<arr.length;k++){
					if(arr[i][k]!=0){
						ctx.beginPath();//准备动作
						ctx.arc(grid/2+k*grid,grid/2+i*grid,grid/2.5,0,Math.PI*2);//参数
						if(arr[i][k]==1){
							ctx.fillStyle='black';
						}else{
						    ctx.fillStyle='white';	
						}	
				         ctx.fill();
					}
				}
			}	
			
		
	}
	
	
})