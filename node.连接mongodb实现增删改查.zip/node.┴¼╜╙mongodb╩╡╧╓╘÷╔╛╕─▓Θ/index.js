const express=require('express');
const mongodb=require('./www/js/packaging.js');
const ObjectId=require('mongodb').ObjectId;
//创建服务器
const app=express();
app.use('/',express.static('./www'));
//添加数据
app.use('/add',(req,res)=>{
	let obj={
		title:req.query.title,
		price:req.query.price,
		amount:req.query.amount
	}
	mongodb.insert('commodity','a',obj,(a)=>{
		mongodb.findAll('commodity','a',(s)=>{
			res.send({
				a:a,
				s:s.length,
			});
		});
	});
})
//m模糊查询
app.use('/inquire',(req,res)=>{
	let obj=req.query.val;
	console.log(obj);
	mongodb.inquire('commodity','a',obj,(a)=>{
		res.send(a);
	})
})
//显示所有数据
//分页显示数据
app.use('/showAll',(req,res)=>{
	let number=parseInt(req.query.count);
	mongodb.findAll('commodity','a',(s)=>{
		mongodb.findAll('commodity','a',(a)=>{
			res.send({
				a:a,
				s:s.length
			});
		},number,10);	
	})
	
})
//删除数据
app.use('/del',(req,res)=>{
	let id=req.query._id;
	let obj={
		_id:new ObjectId(id)
	}
	mongodb.del('commodity','a',(a)=>{
		mongodb.findAll('commodity','a',(s)=>{
			res.send({
				t:'true',
				s:s.length,
			});
		})
	},obj);
})
//更新数据
app.use('/update',(req,res)=>{
	let news=req.query.news;
	let old=req.query.old;
    mongodb.update('commodity','a',old,news,(a)=>{
        res.send('true');
    });
});
//排序
app.use('/sort',(req,res)=>{
	let obj={price:parseInt(req.query.likes)};
	mongodb.sort('commodity','a',obj,(a)=>{
		mongodb.findAll('commodity','a',(s)=>{
			res.send({
				a:a,
				s:a.length,
			});
		})
	})
	
})
//批量删除
app.use('/delAll',(req,res)=>{
	let list=req.query.list;
	let newList=[]
	if(list){
		for(var i=0;i<list.length;i++){
			newList.push(new ObjectId(list[i]));
		}
	}
	mongodb.del('commodity','a',(a)=>{
        mongodb.findAll('commodity','a',(s)=>{
			res.send({
				s:s.length,
				});
		})
	},{"_id":{'$in':newList}});
	
	
})
app.listen('8899');