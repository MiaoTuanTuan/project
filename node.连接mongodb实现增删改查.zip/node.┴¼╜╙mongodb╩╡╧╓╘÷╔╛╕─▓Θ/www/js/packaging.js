const mongodb=require('mongodb').MongoClient;
const url='mongodb://localhost:27017';
//把数据库连接操作封装起来

function _connect(callback){
	mongodb.connect(url,function(err,db){
		if(err) throw err;
		callback(db);
	})
}
//添加数据
module.exports.insert=function(drname,gather,obj,callback){
	_connect(function(db){
		if(!(obj instanceof Array)){
			obj=[obj];
		};
		db.db(drname).collection(gather).insertMany(obj,(err,data)=>{
			if(err) throw err;
			db.close();//关闭文件;
			callback(data);
		})
	})
}
//查询所有数据
module.exports.findAll=function(drname,gather,callback,skip=0,limit=0){
	_connect(function(db){
		db.db(drname).collection(gather).find({}).skip(skip).limit(limit).toArray((err,a)=>{
			if(err) throw err;
			db.close();
			callback(a);
		})
	})
}
//模糊查询
module.exports.inquire=function(drname,gather,obj,callback){
	_connect(function(db){
		db.db(drname).collection(gather).find({'title':{'$regex':obj}}).toArray((err,a)=>{
			if(err) throw err;
			db.close();
			callback(a);
		})
	})
}
//删除数据
module.exports.del=function(drname,gather,callback,obj={}){
	_connect(function(db){
		db.db(drname).collection(gather).deleteMany(obj,(err,a)=>{
			if(err) throw err;
			db.close();
			callback(a);
		})
	})
}
//更新数据
module.exports.update=function(drname,gather,obj,obj2,callback){
	_connect(function(db){
		db.db(drname).collection(gather).updateOne(obj,{$set:obj2},function(err,a){
			if(err) throw err;
			db.close();
			callback(a);
		})
	})
}
//升序降序
module.exports.sort=function(drname,gather,obj,callback,skip=0,limit=0){
    _connect(function(db){
		db.db(drname).collection(gather).find({}).sort(obj).skip(skip).limit(limit).toArray((err,a)=>{
			if(err) throw err;
			db.close();
			callback(a);
		})
	})	
	
	
	
}