$(function(){
	var n=0;//全局变量
	var unde=[];//用来识别以播放的歌曲
	var degs=0;//旋转度数
	//获取音频标签
	var timess;
	var true_false=true;
	var monitor_rotate=false;//监听光盘是否转动
	var audio=$('#box footer audio').get(0);
	var temp_ss=[500];
	function deg(){
		degs++;
		$('#picture').css('transform','rotate('+degs+'deg)')
		monitor_rotate=true;
	}

	//1播放暂停按钮
	var setTime;
	$('#playBack').on('click',function(){
	    if(audio.paused){//paused值为真时表示暂停状态，为假时表示播放状态
			audio.play();//播放音频文件
			$('#playBack').attr('src','img/icon_c3uo4zcbvw9/zanting.png');
		    // $('#picture').addClass('rotate')
			if(monitor_rotate){
				clearInterval(setTime);
			}
		    setTime=setInterval(deg,20);
		}else{
			audio.pause();
			$('#playBack').attr('src','img/icon_c3uo4zcbvw9/bofang_1.png');
		    // $('#picture').removeClass();
            clearInterval(setTime);
			monitor_rotate=false;
		}		
	});
	// setInterval(function(){
	// 	console.log('我要相信自己');
	// },temp_ss[0]);
	//2获取音频长度
	function sum_time(){
		audio.oncanplay=function(){
			var t;
			t=audio.duration;
			// console.log(t);
			$('#plan').attr('max',t);
			// console.log($('#plan').attr('max'));
			t=parseInt(t/60)+':'+(parseInt(t%60)<9?'0'+parseInt(t%60):parseInt(t%60));//这里的长度是随歌曲固定的
			var temp=$('#foot_ul li').eq(5).text(t);		
		}	
	}
	//3当音量改变的时候
	audio.onvolumechange=function(){
		var m=audio.volume;
        $('#volume').val(m);
		// console.log('音量设置');
	}
	//4设置音量
	$('#volume').on('input',function(){
		var temp=$('#volume').val();
		var str=parseInt((temp/1)*100)+'%';
		if(temp==0){
			$('#trumpet').attr('src','img/icon_c3uo4zcbvw9/jingyin_1.png').attr('title','静音');
		}else{
		    $('#trumpet').attr('src','img/icon_c3uo4zcbvw9/bofang.png').attr('title','音量:'+str);
		
		}
		audio.volume=temp;
	});
	//5静音设置
	$('#trumpet').on('click',function(){
		if(audio.volume!=0){
			$('#trumpet').attr('src','img/icon_c3uo4zcbvw9/jingyin_1.png').attr('title','静音');
			audio.volume=0;
			$('#plan').val(0);
		}else{
			audio.volume=0.5;
			var str=(0.5/1)*100+'%';
			$('#trumpet').attr('src','img/icon_c3uo4zcbvw9/bofang.png').attr('title','音量:'+str);
		}
	});//对象.currentTime,获取当前音频播放时间，反过来就是设置播放时间；
	//6显示音频播放时间
	audio.ontimeupdate=function(){
		var time=parseInt(this.currentTime);
		$('#plan').val(time);
		time=(parseInt(time/60)>0?parseInt(time/60):'0')+':'+(parseInt(time%60)>9?parseInt(time%60):'0'+parseInt(time%60));
	    $('#foot_ul li').eq(3).text(time);
		// console.log(time);
	}
	//7通过滑动条设置播放时间
	var audio_change=0;//记录状态；
	$('#plan').on('input',function(){
		if(audio.paused){
			 
		}else{
			audio.pause();
			audio_change=1;
		}
		var t=$('#plan').val();
		audio.currentTime=t;
		t=(parseInt(t/60)>0?parseInt(t/60):'0')+':'+(parseInt(t%60)>9?parseInt(t%60):'0'+parseInt(t%60));
		$('#foot_ul li').eq(3).text(t);
	});
	$('#plan').on('mouseup',function(){
		if(audio_change==1){
			audio.play();
			audio_change=0;
		}
		
	});
	//8打开播放菜单
	$('#menus').on('click',function(){	
		var list=$('#list');
		if(list.is(':hidden')){
			list.show();
		}
		else{
			list.hide();
		}
	})
	
	//9显示播放列表
	$('.list_1_1>div').on('click',function(){
		var index=$(this).index();
		if(index==0){
			$('#list ul').hide();
			$('#list ul').eq(0).show();
			var t=musicData.length;
			$('#list p span').eq(0).text(t);
		}
		else{
			$('#list ul').hide();
			$('#list ul').eq(1).show();
			var t=$('.list_1_2 li').length;
			$('#list p span').eq(0).text(t);
		}
		$('.list_1_1 div').css('background-color','white');
		$(this).css('background-color','antiquewhite');
	})
	//10换皮肤颜色
	var replace='pink';
	$('#color').on('input',function(){
		var temp=$('#color').val();
		$('#box header').css('background-color',temp);
		$('#box footer').css('background-color',temp);
	 //    replace=temp;
		// var r=parseInt(temp.slice(1,3),16);
  //   	var g=parseInt(temp.slice(3,5),16);
  //   	var b=parseInt(temp.slice(5),16);
		// var r_1=parseInt(replace.slice(1,3),16);
		// var g_1=parseInt(replace.slice(3,5),16);
		// var b_1=parseInt(replace.slice(5),16);
		// $('#desktop').css('color','white').css('background-image','rgba('+r,g,b+')');
		// console.log(r,g,b);
	});
	//点击登陆会弹出一个登陆框
	$('#logIn').on('click',function(){
		var temp=$('#logIn b').text();
		if(temp=='登陆'){
			$('#masklayer').show();
			$('.adddiv').show();	
		}
		else{
			$('#logIn_ul').show();
		}
	})
	//11取消登录框
	$('.adddiv img').on('click',function(){
		$('#masklayer').hide();
		$('.adddiv').hide();
	});
	//12上一曲
	$('#foot_ul li:nth-child(1)').on('click',function(){
		n--;
		var temp=!audio.paused;;
		//上一首的播放状态；
		if(n<0){
			n=3;
		}
		$(audio).attr('src',musicData[n].url);
		// $('#playBack').attr('src','img/暂停.jpg');
	    fill(n);
		addList(n);
		if(temp){//为真时就接这播放，为假时就不播放
			audio.play();
		}
	});
	//将歌曲添加到历史纪录的函数
	function addList(n){
		var li=$('.list_ul_1 li').eq(n).clone();
		var ht=li.html();
		var ul_2=$('.list_1_2');
		var t=0;
		li.css('background-color','white');
		for(var i=0;i<unde.length;i++){
			if(unde[i].name[0].innerHTML==ht){
				t++;
			}
		}
		if(t===0&&unde.length<$('.list_ul_1 li').length){
			ul_2.append(li);
			var arr={
				  name:li,
				  id:n
			};
			unde.push(arr);//将当前数据保存在一个数组里
		}
		var log=$('.list_1_2 li').length;
		$('#list p span').eq(0).text(log);
	}
	//13下一曲
	$('#foot_ul li:nth-child(3)').on('click',function(){
		n++;
		var temp=!audio.paused;
		if(n>3){
			n=0;
		}
		$(audio).attr('src',musicData[n].url);
		// $('#playBack').attr('src','img/暂停.jpg');		
		fill(n);
		addList(n);
		if(temp){//为真时就接这播放，为假时就不播放
			audio.play();
		}
	});
	//14一个专门用来填充数据的函数
	fill(n);
	function fill(n){
		//切歌清空桌面歌词
		// $('#desktop').html('-----网易云音乐-----<img src="img/icon_c3uo4zcbvw9/zhuomiangeci_guanbi.png">');
		
		var temp=lrcs[n].lyric[0].lineLyric;
		var str="<img src='img/icon_c3uo4zcbvw9/zhuomiangeci_guanbi.png'>";
		for(var a=0;a<temp.length;a++){
		     str+='<span>'+temp[a]+'</span>'
		}
		$('#desktop').html(str); 
		//放大图片
		sum_time();
		$(audio).attr('src',musicData[n].url);
		$('#box_body_2>img').attr('src',musicData[n].cover);
		//专辑信息，歌词
		$('#box_body_1 h1').text(musicData[n].song);
		$('#box_body_1 li:nth-child(1) span').text(musicData[n].album);//专辑
		$('#box_body_1 li:nth-child(2) span').text(musicData[n].singer);//歌手
		$('#box_body_1 li:nth-child(3) span').text(musicData[n].source);//专辑
		
		$('.body_ul_2').html('');//清空歌词列表
		for(var i=0;i<lrcs[n].lyric.length;i++){
			var temp=lrcs[n].lyric[i].lineLyric;
			$("<li>"+temp+"</li>").appendTo($('.body_ul_2'));
		}//放歌词
		//放评论
		$('#comment').html('');
		for(var i=0;i<musicData[n].msg.length;i++){
			var use=parseInt(musicData[n].msg[i].userId)-1;
			var temp=$("<li class='addLi' style='margin-top:30px'>"
								+"<img src="+users[use].pic+">"
								+"<ul>"
								+	"<li><span>"+users[use].name+"：</span>"+musicData[n].msg[i].megCon+"</li>"
			                    +	"<li>"+musicData[n].msg[i].date+"</li>"
								+	"<li>回复</li>"
			                    +	"<li>|</li>"
								+	"<li>分享</li>"
								+	"<li>|</li>"
			                    +	"<li>点赞</li>"
							+	"</ul>"
						+	"</li>");
			temp.appendTo($('#comment'));	
		}
		//添加到播放列表
		$('.list_ul_1').html('');
		for(var i=0;i<musicData.length;i++){
			$('.list_ul_1').append($('<li>'+musicData[i].song+'<span style="right:0px;position:absolute;">'+musicData[i].singer+'</span></li>'));
			var temp=musicData.length;
			$('#list p span:nth-child(1)').text(temp);
		}
		//歌名列表样式
		$('.list_ul_1 li').removeClass();
		$('.list_ul_1 li').eq(n).addClass('list_style');
		//滚动条
		scroll_2(n);
		//评论框歌曲名
		$('#remark p span').text(musicData[n].song);
	}
	//15播放列表里选择歌曲
	$('.list_ul_1').on('click','li',function(){
		var index=$(this).index();
		var ht=$(this).html();
		var li=$(this).clone();
        var ul_2=$('.list_1_2');
		var li_2=$('.list_1_2 li');
		var t=0;
		for(var i=0;i<li_2.length;i++){
			if(unde[i].name[0].innerHTML==ht){
				t++;
			}
		}
		if(t===0){
			ul_2.append(li);
			var dx={
				  name:li,
				  id:index
			};
			unde.push(dx);//将当前数据保存在一个数组里
		}
		fill(index);
		audio.play();
		$('#playBack').attr('src','img/暂停.jpg');
	})
	//    循环单曲随机,如何单曲循环，如何自动播放下一首；默认是顺序播放
	//定时器；
	var title_arr=['顺序播放','单曲循环','全部循环','随机播放'];
	var img_arr=['img/icon_c3uo4zcbvw9/shunxubofang.png','img/icon_c3uo4zcbvw9/danquxunhuan.png','img/icon_c3uo4zcbvw9/quanbuxunhuan.png','img/icon_c3uo4zcbvw9/random.png'];
	var index_p=0;
	$('#random').on('click',function(){
		index_p++;
	    if(index_p==title_arr.length){
			index_p=0;
		}
		$(this).attr('src',img_arr[index_p]).text('title',title_arr[index_p]);	
	});
	//默认情况
	function mo(n){
		if(n<musicData.length){
			fill(n);
			audio.play();
		}
		else{
			n=musicData.length-1;
			$('#playBack').attr('src','img/icon_c3uo4zcbvw9/zanting.png');
			$('#picture').removeClass();
		}
	}
	audio.onended=function(){
		// mo(n);
		switch(index_p){
			case 0://顺序播放，播完就结束了
			    n++;
				if(n<musicData.length){
					fill(n);
					audio.play();
				}else{
					n=musicData.length-1;
					$('#playBack').attr('src','img/icon_c3uo4zcbvw9/bofang_1.png');
					$('#picture').removeClass();
				}
			    break;
			case 1://单曲循环 播放当前这首
			    fill(n);
				audio.play();
				break;
			case 2://全部循环·
			    n++;
				if(n==musicData.length){
					n=0;
				}
				fill(n);
				audio.play();			
				break;
			case 3://随机播放
			    var temp=Math.floor(Math.random()*musicData.length);
				fill(temp);
				audio.play();
				break;
		}
	}
	//21歌词同步显示 滚动条
	function scroll(n){
		    var scrollTop=0;
		    var sum=0;//监听变量
		    var ts=0;//监听变量
		    var gun=$('.body_ul_2').get(0);
		    gun.scrollTop=0;//设置滚动条初始值
		    audio.ontimeupdate=function(){
				 //获取当前播放状态
				 var time=this.currentTime;
				 $('#plan').val(time);
				 time=(parseInt(time/60)>0?parseInt(time/60):'0')+':'+(parseInt(time%60)>10?parseInt(time%60):'0'+parseInt(time%60));
				 $('#foot_ul li').eq(3).text(time);
				 var t=parseInt(audio.currentTime);
				 console.log(t);
				 //还要获取列表中的歌词信息
				 //如何让滚动条也跟着同步？
				 //事件监听在不停的变化，强制转换之后，t，有时候一秒中之内会是几个相同的数，
				 //为了确保，每段歌词，只操作一次，定义监听变量
				 var list_gechi=$('.body_ul_2 li');	
				 for(var i=0;i< lrcs[n].lyric.length;i++){
					 if(lrcs[n].lyric[i].time==t&&sum==0){
						list_gechi.removeClass();
						list_gechi.eq(i).addClass('list_style');
						scrollTop=50*i-150;
						gun.scrollTop=scrollTop;		
		                sum++;
						ts=t;			
					}
					if(t-1==ts){
						sum=0;
					}
				 }
	    	};
		
	}
	//补充 歌词列表暂停滚动
    $('.body_ul_2').hover(function(){
		true_false=false;
	},function(){
		true_false=true;
	});
	//歌词同步
	function scroll_2(n){
		var gun=$('.body_ul_2').get(0);
		gun.scrollTop=0;//设置滚动条初始值
		var scrollTop=0;
		var on_off=0
		var on_off_1=0;
		var on_off_2=0;
		var on_off_3=0;
		var color_temp=0;
		var color_r='#'//随机颜色；
		var arr=[];//用来保存句歌词的时间差
		for(var i=0;i<lrcs[n].lyric.length;i++){
			arr.push(lrcs[n].lyric[i].time);
		}
		//其实这个时间最大值到最小值的差才是滚动条真正要滚动的距离，
		var arr_1=[];
		//每句歌词之间的时间差
		for(var i=0;i<arr.length;i++){
			if(arr[i+1]!=undefined){
				arr_1.push(arr[i+1]-arr[i]);
			}
		}
		var now_lyric=[];//将当前播放歌曲的歌词全部取出来，放到数组中
		for(var i=0;i<lrcs[n].lyric.length;i++){
			now_lyric[i]=lrcs[n].lyric[i].lineLyric;
	        
		}
		//计算每一句的每一个字所需要的平均时间
		var arr_lyric=[];//新歌词时间数组
		for(var i=0;i<now_lyric.length;i++){
			var now_lyric_1=[];//临时变量
			var temporar=arr[i];//临时变量
			for(var k=0;k<now_lyric[i].length;k++){
				temporar+=Number(((arr_1[i]/now_lyric[i].length)*0.8).toFixed(2));
				now_lyric_1[k]= temporar;	 
			}
			arr_lyric.push(now_lyric_1);
		}
		// console.log(now_lyric);
		//去掉歌词时间数组里最后一行，时间为NaN的情况；
        var temporary_1=arr[arr.length-1];
		var temporary_2=lrcs[n].lyric[lrcs[n].lyric.length-1].lineLyric;
		arr_lyric[arr_lyric.length-1]='';
		now_lyric=[];
		for(var j=0;j<temporary_2.length;j++){
		    temporary_1+=0.4;
			now_lyric[j]=temporary_1;		
		}
		arr_lyric[arr_lyric.length-1]=now_lyric;		
		//现在分两步进行，1：先渲染当前的整句歌词，2：找到当前歌词每个字对应的时间点，根据索引对每个字改变颜色
		        // console.log(arr);//播放时间
				// console.log(arr_1);//每一句实时间差
				audio.ontimeupdate=function(){
					 var time=this.currentTime;
					 $('#plan').val(time);
					 time=(parseInt(time/60)>0?parseInt(time/60):'0')+':'+(parseInt(time%60)>9?parseInt(time%60):'0'+parseInt(time%60));
					 $('#foot_ul li').eq(3).text(time);
					 var t=parseInt(audio.currentTime);
					 var t_1=audio.currentTime;
					 //还要获取列表中的歌词信息
					 //如何让滚动条也跟着同步？
					 //事件监听在不停的变化，强制转换之后，t，有时候一秒中之内会是几个相同的数，
					 //为了确保，每段歌词，只操作一次，定义监听变量
					var list_gechi=$('.body_ul_2 li');
					// var color_r='#';//随机十六进制色；
					var sr=['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'];
					for(var i=0;i< lrcs[n].lyric.length;i++){
						//只产生一次随机颜色的监听变量
						if(t==on_off_1){
							on_off=0;
						}
						if(t==lrcs[n].lyric[i].time&&on_off==0){
							on_off++;
							on_off_1=arr[i+1];
							//正在唱的句子加颜色
							color_r='#';//随机十六进制色；
							for(var ip=0;ip<6;ip++){
							 	var r=Math.floor(Math.random()*sr.length);
								color_r+=sr[r];
							}
						}
						var length_ly=(i+1)<arr.length?(i+1):arr.length;
						if(lrcs[n].lyric[i].time<t_1){
							var temp=lrcs[n].lyric[i].lineLyric;
							var str="<img src='img/icon_c3uo4zcbvw9/zhuomiangeci_guanbi.png'>";
							for(var a=0;a<temp.length;a++){
							     str+='<span>'+temp[a]+'</span>'
							}
							$('#desktop').html(str); 
						}
						// color_r='#';//五颜六色的变色；
						// for(var ip=0;ip<6;ip++){
						//  	var r=Math.floor(Math.random()*sr.length);
						// 	color_r+=sr[r];	
						// }
						var span=$('#desktop span');
						for(var k=0;k<arr_lyric[i].length;k++){
							if(t_1>arr_lyric[i][k]){
								span.eq(k).css('color',color_r);
							}
						}
						
					}
					for(var i=0;i< lrcs[n].lyric.length;i++){
					    if(lrcs[n].lyric[i].time==t){
							list_gechi.removeClass();
							list_gechi.eq(i).addClass('list_style');
						}
						if(true_false){
							if(arr[i+1]!=undefined&&t>arr[i]&&t<arr[i+1]){
								gun.scrollTop=i*50-150;
							}	
                        }
					}			   
				}
			}
		//桌面歌词，每一个变换颜色

	     //22点哪儿播哪儿
		 $('.body_ul_2').on('click','li',function(){
			var index=$(this).index();
			var temp=lrcs[n].lyric[index].time;
			audio.currentTime=temp;		 
		 });
		 //23打开做桌面菜单
		 $('#img_zuomian').on('click',function(){
			var temp=$('#desktop');
			if(temp.is(':hidden')){
				temp.show();
				
			}else{
				temp.hide();
			}
		 });
		 //24桌面歌词拖拽
	    var div=$('#desktop');
		$('#desktop').on('mousedown',function(e) {
		   var x=e.pageX-$(this).offset().left;
		   var y=e.pageY-$(this).offset().top;
		   $(this).on('mousemove',function(e){
			   var x1=e.pageX;
			   var y1=e.pageY;
			   x1=x1-x;
			   y1=y1-y;
			   $(this).css({
				   top:y1,left:x1,margin:0
			   })   
		   });
	    });
		 $('#desktop').on('mouseup',function(){
			 $(this).off('mousemove');
		 });
		 //25关闭
		 $('#desktop').on('click','img',function(){
			 $('#desktop').hide();
		 })
	    //26如何判断有没有登陆
	    $('#box_body_3 input').on('click',function(){
			var temp=$('#logIn b').text();
			console.log(temp);
			if(temp=='登陆'){
				$('#masklayer').show();
				$('.adddiv').show();
				return;
			}
			//弹出一个评论框
		    $('#remark').show();
			$('#remark p span').text(musicData[n].song);
		 });
		 //27关闭评论框
         	$('#remark img').on('click',function(){
				$('#remark').hide();
			})	 
	    //28评论
		$('#remark b').on('click',function(){
			//判读登陆的是谁，跟据显示的名字
			var name=$('#logIn b').text();
			var index=0;
			for(var i=0;i<users.length;i++){
				if(name==users[i].name){
					index=i;
					break;
				}
			}
			var temp=$('#remark textarea').val();
			//把这个值存储在数组里，调用填充函数;
			var time=new Date();
			var y=time.getFullYear();//年
			var m=time.getMonth();//月
			var d=time.getDate();
			var h=time.getHours();//小时
			var min=time.getMinutes();//分
			var s=time.getSeconds()//秒
			var str=y+'-'+m+'-'+d+'-'+(h<10?'0'+h:h)+':'+(min<10?'0'+min:min)+':'+(s<10?'0'+s:s);
			console.log(str);
			var id=musicData[n].msg.length+1;
			var arr={
				     "megId":id,
					 "megCon":temp,
				     "date":str,
					 "userId":index+1
		        	};
			musicData[n].msg.push(arr);
            fill(n);
			$('#remark').hide();

		})
		//28登陆
		$('.adddiv li:nth-child(5)').on('click',function(){
			var name=$('.adddiv input').eq(0).val();
			var password=$('.adddiv input').eq(1).val();
			$.ajax({
				url:'http://localhost:8989/new',
				method:'post',
				data:{
					name:name,
					password:password
				},
				success:(res)=>{
				    	
				}
			})
			var ajax=new XMLHttpRequest();
			ajax.open('GET','文件/users.txt',true);
			ajax.send();
			ajax.onreadystatechange=function(){
				if(ajax.readyState==4&ajax.status==200){
					var temp=ajax.response;
				    temp=eval(temp);
					console.log(temp);
					var temppor=0;
					for(var i=0;i<temp.length;i++){
						if(name==temp[i].name){
							temppor=temp[i].name;
							break;
						}
					}	
						
					if(name=temppor){	
 						if(password==temp[i].pwd){
							$('#logIn b').text(temp[i].name);
							$('#box header li:nth-child(4) img').attr('src',temp[i].pic);
							$('.adddiv').hide();
							$('#masklayer').hide();
							$('#hint').text('');
							var checked=$('#check').prop('checked');
							console.log(checked);
							window.localStorage.setItem('username',name);
							window.localStorage.setItem('pwd',password);
							if (checked) {
							    window.localStorage.setItem('username',name);
							    window.localStorage.setItem('pwd',password);
							}
							else{
							    window.localStorage.removeItem('username');
							    window.localStorage.removeItem('pwd');
							}
						}
						else{
							$('#hint').text('请输入正确的密码');
							}
					}else{
							if(name==''){
								$('#hint').text('还未输入信息');
							}
							else{
								
								$('#hint').text('用户名错误');
							}
							
						}
							
					
					console.log(name,password);
				
		    	}
			}
			
		});
		function ajax(get,url,f){
			var ajax=new XMLHttpRequest();
			ajax.open(get,url,true);
			ajax.send();
			ajax.onreadystatechange=function(){
				if(ajax.readyState==4&ajax.status==200){
	                  var data=ajax.response;
					  return f(data);
	        }   }
		}
	     //29登提示陆框
	    $('.adddiv li input').eq(0).on('input',function(){
			ajax('GET','文件/users.txt',function(data){
				data=eval(data);
				$('#hint_1').html('');
			    for(var i=0;i<data.length;i++){
				     var name=data[i].name	
					 $('#hint_1').show();
					 $('<li>'+name+'</li>').appendTo($('#hint_1'));
				}
			})
			
			
		});
	    //30登陆框提示，鼠标离开
		$('#hint_1').hover(function(){
			$(this).show();
		},function(){
			$('#hint_1').hide();
			
		});
	    //31登陆框提示 提示点击
		$('#hint_1').on('click','li',function(){
			var t=$(this).text();
			$('.add input').eq(0).val(t);
			$('#hint_1').hide();
		})
	    //32退出登录
		$('#logIn_ul li').eq(1).on('click',function(e){
			$('#logIn_ul').hide();
			$('#logIn b').text('登陆');
			$('#masklayer').show();
			$('.adddiv').show();
			$('#box header li:nth-child(4) img').attr('src','img/登陆.jpg');
		    return false;
		})
		//33退出登录隐藏
		$('#logIn_ul').hover(function(){
			$(this).show();
		},function(){
			$(this).hide();
			
		})
	    //34历史纪录点击播放
		$('.list_1_2').on('click','li',function(){
			var x=$(this).html();
			var log=$('.list_1_2 li').length;
			for(var i=0;i<unde.length;i++){
			     if(x==unde[i].name[0].innerHTML){
					 fill(unde[i].id);
					 audio.play();
					 break;
				 }
			}
			$('#list p span').eq(0).text(log);
		});
		//35清空历史纪录
		$('#list p span').eq(1).on('click',function(){
			unde=[];
			if(!$('.list_1_2').is(":hidden")){
				$('.list_1_2').html("");
				$('#list p span').eq(0).text(0);
			}
			
		});
		//搜索框提示数据
		$('#seek').on('input',function(){
		    $('#seek ul').show();
			$('#seek ul').html('');
			var value=$('#seek input').val();
			var reg=new RegExp('^[a-zA-Z]');
            var v=value.slice(0,1);
			for(var i=0;i<musicData.length;i++){
				var t=musicData[i].song;
				var t_1=t.slice(0,1);
				if(v==t_1){
					var li=$('<li>'+t+'</li>');
					li.appendTo($('#seek ul'));	
				}
				
			}
		})
		$('body').on('click',function(){
			$('#seek ul').hide();
		})
		$('#seek ul').on('click','li',function(){
            var a=0;
			var t=$(this).text();
			for(var i=0;i<musicData.length;i++){
				if(t==musicData[i].song){
					a=i;
					break;
				}
			}
			fill(a);
		})
	
		//缓存数据
		var username = window.localStorage.getItem('username');
	    if (username) {
		    $(".add input").eq(0).val(username);
		    $(".add input").eq(1).val(window.localStorage.getItem('pwd'));
		    $('.add input').eq(2).prop('checked',true);
	    }
		// $('#log').on('click',function(){
			
		// })
});