const fs=require('fs');
const path=require('path');
const http=require('http');
const url=requrire('url');
const querystring=requrire('querystring');
let server=http.createServer((req,res)=>{
	if(req.url=='/favicon.ico') return;
	
	
})
server.listen('8888');