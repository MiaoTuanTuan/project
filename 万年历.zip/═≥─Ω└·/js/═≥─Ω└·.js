$(function(){
	//渲染数据
	var time=new Date();
	// console.log(time);
	var year=time.getFullYear();
	var month=time.getMonth();
	var day=time.getDate();
	showDate(time);
	$('#box span').on('click',function(){
		var index=$(this).index();
		// console.log(index);
		switch(index){
			case 0:
			    month--;
			    break;
			case 1:
			    year--;
			    break;
			case 2:
			    month++;
			    break;
			case 3:
			    year++;
			    break;
		}
		date=new Date(year,month);
		showDate(date)
	});
	function showDate(time){
		var tds=$('#box tbody td');
		tds.empty();//清空td所有内容
		//设置表头 显示年月
		var year=time.getFullYear();//获取年份
		var month=time.getMonth()+1;//获取月份加一
		var date=time.getDate();//获取今天是当月几号
		// console.log(year,month+1,date);
		$('#box header div').text(year+'年'+month+'月');
     //		将天数显示出来
	    //new一个当前时间，根据当前时间，获取当月的天数
		//月份后面不写天数默认是当月第一天，写零，表示上月最后一天；
		var nowDate=new Date(year,month,0);//通过上个月获取当月的天数
		var days=nowDate.getDate();//获取天数
		nowDate=new Date(year,month-1,1);//获取当月一号是新期几//month-1表示月份是0~11，我们没有零月，显示的时候加一，获取的时候还有减回来；
		var week=nowDate.getDay();//获取星期//星期天表示零；
		// console.log(nowDate,year,month,date);
        //days是一个数字
		//然后如何显示，根据天数和星期填充表格，星期天放在最前面的
		var time_1=new Date();//获取当前时间对比月份
		var year_1=time_1.getFullYear();//当前年
		var month_1=time_1.getMonth();//当前月
		var day=time_1.getDate();//当前天
		// console.log(year_1,month_1);
		//当前时间是死的，前后的时间可以变化
		
		// console.log(days);
		for(var i=0;i<days+1;i++){
			//星期是六倒零，星期天要加一而且星期放在最前面，
			//给表格末尾添加上日期,并改变样式
			// console.log(i);
			if(i==days){
			     var len=tds.length-days-week;
			     for(var j=0;j<len;j++){
			     	$('#box tbody td').eq(week+days+j).css('color','gray');
			     	// console.log('我是里面的数据');
			         tds.eq(days+week+j).text(1+j);
			     }
			     break;//week星期  days当月天数  len 表尾空余的格数
			}
			
		    tds.eq(week+i).html('<b>'+(i+1)+'</b>');
		    tds.eq(i).css('color','black');
		    //给当前天加一点状态
		    if(year_1==year&&month_1+1==month){			
		       tds.eq(day).css('background-color','red').css('color','white');//	    
		    }
		    else{
		     	 tds.eq(week+i).css('background-color','white').css('color','black');		   
		    }
		}
		//开头怎么添加，开头的空格其实是星期造成的，所以要知道上个月的天数
		//获取上个月的天数
		var days_1=new Date(year,month-1,0);
		days_1=days_1.getDate();//上个月的天数
		var week=nowDate.getDay();//获取的是每个月一号的星期几，星期是从零到六如果是星期天就不用执行这一步
		// console.log(tds.length,days_1,week);
		for(var i=(week-1);i>=0;i--){
			tds.eq(i).text(days_1);//这少的一天去哪儿了
			tds.eq(i).css('color','gray');
		    days_1--;				
		}
		
		//今天只显示一次,要做特殊处理
		//一共六行，处理最后两行空行情况；
		if(tds.eq(28).text()===''){
			tds.eq(28).parent().hide();
			tds.eq(35).parent().hide();
		}
		else if(tds.eq(35).text()===''){//最后一行为空不显示
			tds.eq(35).parent().hide();
		}
		else{
			tds.eq(28).parent().show();
			tds.eq(35).parent().show();
		}
	}
	//time是当前时间
	//显示函数写完了,通过设置时间来设置每个月的月份和年份
	//如果表头空的部分填上个月的数，表尾空的部分填下个月的数
	//表尾的部分是不是可以接着当前月分接着往下写
	//是否专门写一个显示表头表尾字体样式的函数
	//写一个现在时间
	// setInterval(console.log('输出'),100);
	
	function ding(){
			var time_2=new Date();
			// console.log(time);
			var year_2=time_2.getFullYear();//年
			var month_2=time_2.getMonth();//月
			var day_2=time_2.getDate();//日
			var week_2=time_2.getDay();//星期
			var hours_2=time_2.getHours()//时
			var minutes_2=time_2.getMinutes()//分
			var seconds_2=time_2.getSeconds()//秒；
			$('#show').html('北京时间：<b>'+year_2+'</b>年<b>'+(month_2+1)+'</b>月<b>'+day_2+'</b>日<b>'+hours_2+'</b>时<b>'+minutes_2+'</b>分<b>'+seconds_2+'</b>秒');
			
		}
		ding();
		window.setInterval(ding,500);
		// window.setInterval(ding,500);
});